package com.zp.test;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtils {

	private Connection mConnection;

	public Connection getConnection() {
		try {
			String driver = "";
			String url = "";
			String userName = "";
			String password = "";
			Properties properties = new Properties();
			InputStream in = this.getClass().getClassLoader().getSystemResourceAsStream("DBConfig.properties");
			properties.load(in);
			driver = properties.getProperty("driver");
			url = properties.getProperty("url");
			userName = properties.getProperty("username");
			password = properties.getProperty("password");
			Class.forName(driver);
			mConnection = DriverManager.getConnection(url, userName, password);
			return mConnection;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public void closeConnection() {
		if (mConnection != null) {
			try {
				mConnection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
