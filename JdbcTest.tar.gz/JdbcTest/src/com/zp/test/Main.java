package com.zp.test;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.Statement;
import java.sql.Types;


public class Main {
	static DBUtils dbUtils;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		dbUtils = new DBUtils();
		// updateResult();
//		queryCallableStatement();
//		insertCallableStatement();
		getNameById();
	}
	
	static void getNameById(){
		Connection connection = dbUtils.getConnection();
		try {
			CallableStatement cstmt = connection.prepareCall("{call selectNameById(?,?)}");

			cstmt.setInt(1, 8);
			cstmt.registerOutParameter(2,Types.VARCHAR);
			cstmt.execute();
			String name = cstmt.getString(2);
			System.out.println("name = "+ name);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	static void insertCallableStatement() {

		Connection connection = dbUtils.getConnection();
		try {
			CallableStatement cstmt = connection.prepareCall("{call insert_user(?,?)}");

			cstmt.setString(1, "canima");
			cstmt.setInt(2, 5);
			cstmt.execute();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	static void queryCallableStatement() {

		Connection connection = dbUtils.getConnection();
		try {
			CallableStatement cstmt = connection.prepareCall("{call select_user()}");

			ResultSet rs = cstmt.executeQuery();
			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				int age = rs.getInt(3);
				System.out.println("id = " + id + "  name = " + name + " age = " + age);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	static void updateResult() {

		Connection connection = dbUtils.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			String sql = "select * from user";
			stmt = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			rs = stmt.executeQuery(sql);

			rs.absolute(6);
			rs.updateString("name", "ggg");
			rs.updateRow();

			/*
			 * rs.moveToInsertRow(); rs.updateString("name", "王大拿");
			 * rs.updateInt("age", 29); rs.insertRow();
			 */

			// rs.beforeFirst();
			/*
			 * while(rs.next()){ String name = rs.getString("name"); int age =
			 * rs.getInt("age"); System.out.println("name = "+ name+"  age = "
			 * +age); }
			 */
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				stmt.close();
				connection.close();

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	static void testConnection() {
		Connection connection = dbUtils.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			connection.setAutoCommit(false);
			stmt = connection.createStatement();
			String updateSql1 = "update Account set balance = balance-100 where name='Tom'";
			String updateSql2 = "update Account set balance = balance+100 where name='Lily'";
			stmt.executeUpdate(updateSql1);
			stmt.executeUpdate(updateSql2);
			connection.commit();

			String querySql = "select * from Account";
			rs = stmt.executeQuery(querySql);
			while (rs.next()) {
				StringBuilder sb = new StringBuilder();
				sb.append(rs.getString(1)).append("  ").append(rs.getInt(2));
				System.out.println(sb);
			}

		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				rs.close();
				dbUtils.closeConnection();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

}
